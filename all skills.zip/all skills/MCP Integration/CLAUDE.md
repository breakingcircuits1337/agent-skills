# MCP Integration Skill

This skill should be used when the user asks to add MCP server, integrate MCP, configure MCP in plugin, use .mcp.json, set up Model Context Protocol, connect external service, mentions ${CLAUDE_PLUGIN_ROOT} with MCP, or discusses MCP server types (SSE, stdio, HTTP, WebSocket). Provides comprehensive guidance for integrating Model Context Protocol servers into Claude Code plugins for external tool and service integration.

## Documentation
Refer to [SKILL.md](SKILL.md) for full documentation and usage examples.
